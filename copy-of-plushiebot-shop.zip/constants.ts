import { Product } from './types';

export const PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Плюшевый Мишка "Тедди"',
    price: 1500,
    description: 'Классический коричневый мишка, очень мягкий и уютный. 30 см.',
    imageUrl: 'https://picsum.photos/400/400?random=10'
  },
  {
    id: '2',
    name: 'Гигантский Осьминог',
    price: 2500,
    description: 'Двусторонний осьминог-перевертыш. Синий и розовый цвета.',
    imageUrl: 'https://picsum.photos/400/400?random=20'
  },
  {
    id: '3',
    name: 'Капибара Релакс',
    price: 1800,
    description: 'Самое спокойное животное в мире теперь у вас дома. 25 см.',
    imageUrl: 'https://picsum.photos/400/400?random=30'
  },
  {
    id: '4',
    name: 'Зайка в Худи',
    price: 1200,
    description: 'Милый белый зайчик в розовом худи. Снимается капюшон.',
    imageUrl: 'https://picsum.photos/400/400?random=40'
  },
  {
    id: '5',
    name: 'Акула из Икеи (Мини)',
    price: 1100,
    description: 'Легендарная акула, но в компактном размере. 40 см.',
    imageUrl: 'https://picsum.photos/400/400?random=50'
  }
];

export const INITIAL_GREETING = "Привет! 👋 Я бот магазина «Плюшевый Рай». У нас самые мягкие игрушки!\n\nИспользуй меню или напиши, что ищешь.";
